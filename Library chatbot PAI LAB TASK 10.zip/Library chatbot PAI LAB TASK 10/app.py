from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# chatbot logic
def get_bot_response(user_input):
    user_input = user_input.lower()

    if "timing" in user_input or "open" in user_input:
        return "Library is open from 9 AM to 5 PM."
    
    elif "book" in user_input:
        return "You can find books in different sections. Please tell the book name."
    
    elif "due" in user_input:
        return "Books must be returned within 14 days."
    
    elif "hello" in user_input or "hi" in user_input:
        return "Hello! How can I help you?"
    
    else:
        return "Sorry, I didn't understand your question."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def chatbot_response():
    user_input = request.form["msg"]
    response = get_bot_response(user_input)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)