from flask import Flask, render_template, request
import PyPDF2
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.lsa import LsaSummarizer

app = Flask(__name__)

def summarize_text(text):
    parser = PlaintextParser.from_string(text, Tokenizer("english"))
    summarizer = LsaSummarizer()
    summary = summarizer(parser.document, 3)
    return " ".join(str(sentence) for sentence in summary)

@app.route("/", methods=["GET", "POST"])
def index():
    summary = ""
    error = ""

    if request.method == "POST":

        # Case 1: PDF upload
        if "pdf_file" in request.files and request.files["pdf_file"].filename != "":
            file = request.files["pdf_file"]

            try:
                pdf_reader = PyPDF2.PdfReader(file)
                text = ""

                for page in pdf_reader.pages:
                    text += page.extract_text()

                if text.strip() == "":
                    error =  "No readable text was found in the PDF."

                else:
                    summary = summarize_text(text)

            except Exception:
                error = "The PDF file is invalid or corrupted."


        # Case 2: Text input
        elif request.form.get("text_input"):
            text = request.form["text_input"]
            summary = summarize_text(text)

        else:
            error = "Please upload a PDF file or enter text to summarize."

    return render_template("index.html", summary=summary, error=error)

if __name__ == "__main__":
    app.run(debug=True)