from nlp.keywords import extract_keywords

def generate_quiz(text, num_questions=5):
    keywords = extract_keywords(text, max_keywords=num_questions)
    questions = []

    for keyword in keywords:
        if keyword in text:
            sentences = text.split('.')
            for sentence in sentences:
                if keyword in sentence and len(sentence.strip()) > 20:
                    question = sentence.strip().replace(keyword, "______")
                    questions.append({
                        "question": question + "?",
                        "answer": keyword
                    })
                    break

    return questions