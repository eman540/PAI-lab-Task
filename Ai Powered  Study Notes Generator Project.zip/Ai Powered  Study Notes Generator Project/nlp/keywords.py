import spacy

nlp = spacy.load("en_core_web_sm")

def extract_keywords(text, max_keywords=10):
    doc = nlp(text)
    keywords = []

    for ent in doc.ents:
        if ent.text not in keywords:
            keywords.append(ent.text)

    if len(keywords) < max_keywords:
        for token in doc:
            if token.pos_ in ["NOUN", "PROPN"] and not token.is_stop:
                if token.text.lower() not in [k.lower() for k in keywords]:
                    keywords.append(token.text)

    return keywords[:max_keywords]