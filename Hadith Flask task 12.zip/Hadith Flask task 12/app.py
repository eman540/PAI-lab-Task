from flask import Flask, request, jsonify, render_template
import numpy as np
import faiss
import pandas as pd
from sentence_transformers import SentenceTransformer

app = Flask(__name__)

print("Loading model and data...")
model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
embeddings = np.load('hadith_embeddings.npy').astype('float32')
faiss_index = faiss.read_index('faiss_index.index')
hadith_df = pd.read_csv('cleaned_hadith_data.csv').reset_index(drop=True)

print(f"CSV rows: {len(hadith_df)}")
print(f"Embeddings shape: {embeddings.shape}")
print("Ready!")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    data = request.get_json()
    query = data.get('query', '').strip()
    count = int(data.get('count', 5))

    if not query:
        return jsonify({'error': 'Query is empty'}), 400

    query_embedding = model.encode([query]).astype('float32')
    distances, indices = faiss_index.search(query_embedding, count)

    results = []
    for i in range(count):
        idx = int(indices[0][i])

        if idx < 0 or idx >= len(hadith_df):
            continue

        row = hadith_df.iloc[idx]

        results.append({
            'rank': len(results) + 1,
            'distance': round(float(distances[0][i]), 4),
            'hadith': str(row['Cleaned_Hadith']) if pd.notna(row['Cleaned_Hadith']) else '',
            'chapter': str(row['Chapter_English']) if 'Chapter_English' in hadith_df.columns and pd.notna(row['Chapter_English']) else '',
        })

    return jsonify({'results': results})

if __name__ == '__main__':
    app.run(debug=True)