import pandas as pd
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer

# Load CSV
print("Loading CSV...")
df = pd.read_csv('cleaned_hadith_data.csv')
print(f"Original rows: {len(df)}")
print(f"Columns: {df.columns.tolist()}")

# Check if data exists
if len(df) == 0:
    print("ERROR: CSV is empty! Please download the original CSV first.")
    exit()

# Remove empty rows from Cleaned_Hadith column
df = df[df['Cleaned_Hadith'].notna()]
df = df[df['Cleaned_Hadith'].str.strip() != '']
df = df.reset_index(drop=True)
print(f"Rows after cleaning: {len(df)}")

# DO NOT overwrite CSV - just use it as is
print("Data loaded successfully!")

# Load model
print("Loading model...")
model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

# Create embeddings
print("Creating embeddings... (5-10 minutes)")
embeddings = model.encode(
    df['Cleaned_Hadith'].tolist(),
    show_progress_bar=True,
    batch_size=64
)
embeddings = np.array(embeddings).astype('float32')
print(f"Embeddings shape: {embeddings.shape}")

# Save embeddings
np.save('hadith_embeddings.npy', embeddings)
print("hadith_embeddings.npy saved!")

# Create FAISS index
print("Creating FAISS index...")
dim = embeddings.shape[1]
index = faiss.IndexFlatL2(dim)
index.add(embeddings)
faiss.write_index(index, 'faiss_index.index')
print("faiss_index.index saved!")

# Final verification
print("\n--- Final Verification ---")
print(f"CSV rows:          {len(df)}")
print(f"Embeddings rows:   {embeddings.shape[0]}")
print(f"FAISS index total: {index.ntotal}")

if len(df) == embeddings.shape[0] == index.ntotal:
    print("\nSUCCESS! All files in sync. Now run: python app.py")
else:
    print("\nMISMATCH DETECTED! Please share output.")