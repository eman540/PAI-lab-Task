qna_data = [
    {
        "question": "What is a library?",
        "answer": "A library is a place where books, magazines, newspapers, and other resources are stored and made available for people to read or borrow."
    },
    {
        "question": "How do I get a library card?",
        "answer": "To get a library card, visit your local library with a valid ID and proof of address. Fill out a registration form and the card is usually issued immediately for free."
    },
    {
        "question": "How long can I borrow a book?",
        "answer": "Most libraries allow you to borrow books for 2 to 4 weeks. You can usually renew the book online, by phone, or in person if no one else has requested it."
    },
    {
        "question": "What happens if I return a book late?",
        "answer": "If you return a book late, you will be charged a fine. The fine amount varies by library but is usually a small fee per day. Some libraries have eliminated late fines entirely."
    },
    {
        "question": "Can I reserve a book that is already borrowed?",
        "answer": "Yes, you can place a hold or reservation on a book. The library will notify you when the book becomes available for pickup."
    },
    {
        "question": "What is the Dewey Decimal System?",
        "answer": "The Dewey Decimal System is a method of organizing library books by subject using numbers. It divides all knowledge into 10 main categories numbered from 000 to 999."
    },
    {
        "question": "Does the library have computers?",
        "answer": "Most public libraries provide computers with internet access for free. You usually need a library card to use them and time slots may be limited."
    },
    {
        "question": "Can I return books to any library branch?",
        "answer": "In most library systems, you can return books to any branch within the same library network. However, returning to a different library system may not be allowed."
    },
    {
        "question": "What is an ebook and can I borrow it from a library?",
        "answer": "An ebook is a digital version of a book you read on a phone, tablet, or computer. Many libraries offer free ebook borrowing through apps like Libby or OverDrive using your library card."
    },
    {
        "question": "What is interlibrary loan?",
        "answer": "An interlibrary loan is a service where your library borrows a book from another library on your behalf. This is useful when your library does not have a specific book you need."
    },
    {
        "question": "Are libraries only for books?",
        "answer": "No, modern libraries offer much more than books. They provide access to magazines, DVDs, audiobooks, digital resources, study rooms, and community programs."
    },
    {
        "question": "What is a reference book?",
        "answer": "A reference book like an encyclopedia or dictionary is meant to be consulted for specific information, not read from cover to cover. Reference books usually cannot be borrowed and must be used inside the library."
    },
    {
        "question": "How do I search for a book in the library?",
        "answer": "You can search for a book using the library's online catalog called OPAC (Online Public Access Catalog). You can search by title, author, subject, or ISBN number."
    },
    {
        "question": "What is a library catalog?",
        "answer": "A library catalog is a database that lists all the materials a library owns. It tells you if a book is available, where it is located, and how to request it."
    },
    {
        "question": "Can children use the library?",
        "answer": "Yes, libraries welcome children and usually have a dedicated children's section with age-appropriate books, storytelling sessions, and educational activities."
    }
]